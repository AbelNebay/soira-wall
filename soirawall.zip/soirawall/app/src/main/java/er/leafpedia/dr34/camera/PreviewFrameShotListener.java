package er.leafpedia.dr34.camera;


public interface PreviewFrameShotListener {

    void onPreviewFrame(byte[] data, Size frameSize);

    // PaxConstants - the only thing I need
}
 