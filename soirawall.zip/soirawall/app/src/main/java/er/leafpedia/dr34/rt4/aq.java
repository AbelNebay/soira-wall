package er.leafpedia.dr34.rt4;


public abstract class aq extends com.aa.aaa.LuminanceSource {

    aq(int width, int height) {
super(width, height);
}

    public abstract byte[] getMatrix();

    public abstract byte[] getRow(int y, byte[] row);

}
 