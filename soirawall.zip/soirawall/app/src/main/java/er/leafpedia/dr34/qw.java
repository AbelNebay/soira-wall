package er.leafpedia.dr34;

import android.content.Intent;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aa.aaa.ResultPoint;
import com.soira.soirawall.R;
import com.soira.soirawall.a6r.aa;
import com.aa.aaaa.aaa.pdf417.decoder.ec.k;
import com.soira.soirawall.gf3.l;

import java.io.File;

import er.leafpedia.dr34.camera.CameraManager;
import er.leafpedia.dr34.camera.PreviewFrameShotListener;
import er.leafpedia.dr34.camera.Size;
import er.leafpedia.dr34.rt4.awe;
import er.leafpedia.dr34.rt4.aq;
import er.leafpedia.dr34.rt4.aw;
import er.leafpedia.dr34.rt4.ar;
import er.leafpedia.dr34.aq2.as;

import static com.aa.aaa.aaa.common.detector.b.EXPIRED;
import static com.aa.aaa.aaa.common.detector.b.INVALID;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_OPTION;
import static com.aa.aaaa.aaa.pdf417.decoder.ec.k.EXPLORER_SOIRA;

@SuppressWarnings("ALL")
public class qw extends AppCompatActivity implements SurfaceHolder.Callback, PreviewFrameShotListener, aw, OnClickListener {
    Typeface font;
    private static final long VIBRATE_DURATION = 200L;
    public static final String EXTRA_RESULT = "result";
    RelativeLayout root;
    private as as;
    private CameraManager cameraManager;
    @Nullable
    private awe mAwe;
    @Nullable
    private Rect previewFrameRect = null;
    private boolean isDecoding = false;
    TextView scan_text;

    ImageView camera_flip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ad);
        root = (RelativeLayout) findViewById(R.id.root_layout);
        font = Typeface.createFromAsset(getAssets(), "soira_font.ttf");
        camera_flip = (ImageView) findViewById(R.id.camera_flip);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }else {
            root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        }

        root.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                }else {
                    root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
                }
            }
        });
        final SurfaceView previewSv = (SurfaceView) findViewById(R.id.sv_preview);
        as = (as) findViewById(R.id.cv_capture);
        ImageButton backBtn = (ImageButton) findViewById(R.id.btn_back);
        scan_text = (TextView) findViewById(R.id.scan_text);
        scan_text.setTypeface(font);

        backBtn.setOnClickListener(this);
        previewSv.getHolder().addCallback(this);
        cameraManager = new CameraManager(this);
        cameraManager.setPreviewFrameShotListener(this);

        camera_flip.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flip == 0){
                    flip = 1;
                }else{
                    flip = 0;
                }
                initialize_camera(previewSv.getHolder(), flip);
            }
        });

}

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        initialize_camera(holder, flip);
    }

    int flip = 0;

    private void initialize_camera(SurfaceHolder holder, int option) {
        if (holder == null) return;
        cameraManager.initCamera(holder, option);
        if (!cameraManager.isCameraAvailable()) {
            Toast.makeText(qw.this, "Camera is not found. Use local file selection.", Toast.LENGTH_LONG).show();

            // TODO: 7/10/2023 Will check the options for finishing the acitivty

//            finish(); // No need for this option...


            // TODO: 7/10/2023 The upper function is to be mentioned later
            return;
        }
        cameraManager.startPreview();
        if (!isDecoding) {
            cameraManager.requestPreviewFrameShot();
        }
    }

    @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        cameraManager.stopPreview();
        if (mAwe != null) {
            mAwe.cancel();
        }
        cameraManager.release();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPreviewFrame(byte[] data, @NonNull Size dataSize) {
        if (mAwe != null) {
            mAwe.cancel();
        }
        if (previewFrameRect == null) {
            previewFrameRect = cameraManager.getPreviewFrameRect(as.getFrameRect());
        }
        ar luminanceSource = new ar(data, dataSize, previewFrameRect);
        mAwe = new awe(luminanceSource, qw.this);
        isDecoding = true;
        mAwe.execute();
    }

    private void makeVibranium(){
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        vibrator.vibrate(VIBRATE_DURATION);
    }

    @Override
    public void onDecodeSuccess(String result, aq source) {
        makeVibranium();
        isDecoding = false;
        Intent resultData = new Intent();
        resultData.putExtra(EXTRA_RESULT, result);
        setResult(RESULT_OK, resultData);
        SELECTED_PATH = null;
        k.DATA_FETCHED = null;
        finish();
    }

    @Override
    public void onDecodeFailed(aq source) {
        isDecoding = false;
        if (EXPIRED){
            makeVibranium();
            EXPIRED = false;
            Toast.makeText(this, "QR Code is expired!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }else if (INVALID){
            makeVibranium();
            INVALID = false;
            Toast.makeText(this, "QR Code is invalid.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        cameraManager.requestPreviewFrameShot();
    }

    @Override
    public void foundPossibleResultPoint(@NonNull ResultPoint point) {
        as.addPossibleResultPoint(point);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

        @Override
        public void onClick(@NonNull View v) {
            switch (v.getId()) {
                case R.id.btn_back:
                    finish();
                    break;
                case R.id.local_button:
                    local_selector();
                    break;
           }
        }

    private void local_selector() {
        EXPLORER_OPTION = EXPLORER_SOIRA;
        startActivity(new Intent(qw.this, aa.class));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @NonNull Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 777 && resultCode == -1){
            String path = l.getUtil(qw.this, data.getData());
            String newPath = new File(path).getParent();
            SELECTED_PATH = newPath;
            finish();
        }
    }

    @Nullable
    public static String SELECTED_PATH = null;
}

