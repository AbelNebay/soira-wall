package er.leafpedia.dr34.camera;

import android.support.annotation.NonNull;

public class Size {
    Size(int w, int h) {
        width = w;
        height = h;
    }
    Size(@NonNull Size src) {
    width = src.width;
    height = src.height;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Size)) {
        return false;
    }
    Size s = (Size) obj;
        return width == s.width && height == s.height;
    }
    public int size() {
    return width * height;
    }
    public int width;
    public int height;

    @NonNull
    @Override
    public String toString() {
    return width + "x" + height;
    }
    }
 