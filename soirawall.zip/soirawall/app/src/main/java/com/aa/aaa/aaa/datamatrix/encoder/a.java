package com.aa.aaa.aaa.datamatrix.encoder;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.aa.aaa.aaa.common.detector.b;
import com.aa.aaa.aaa.multi.mm;
import com.aa.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.aa;
import com.aa.aaa.oned.rss.expanded.decoders.dec.deco.decoders.qedf;
import com.aa.aaaa.aaa.oned.mn;
import com.aaa.Comings;
import com.aaa.SMSRans;
import com.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.Cryptor;
import com.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.we4;
import com.aaa.common.SMSReceiver;
import com.aaa.datamatrix.mq;
import com.aaa.mp;
import com.soira.soirawall.R;
import com.soira.soirawall.a10.s23.wql;
import com.soira.soirawall.a6r.gf;
import com.soira.soirawall.a6r.gvy;
import com.soira.soirawall.a6r.g;
import com.soira.soirawall.aqp.Keyboard;
import com.soira.soirawall.gf3.xxe;
import com.soira.soirawall.frt2.SalesSecurity;
import com.soira.soirawall.frt2.WallSecurity;
import com.soira.soirawall.s24.OnConditionMet;
import com.soira.soirawall.sq3.SoiraButton;
import com.soira.soirawall.sq3.SoiraEditText;
import com.soira.soirawall.sq3.SoiraTextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import static com.aa.aaa.aaa.common.detector.b.LOCAL_PROCESSED;
import static com.aa.aaa.aaa.common.detector.b.QR_PROCESSED;
import static com.aa.aaa.aaa.common.detector.b.SOIRA_SALES;

@SuppressWarnings("ALL")
public class a extends AppCompatActivity {
    boolean opened = false, dialog_opened, contact_opened;
    SoiraButton request_button, ok_button;
    SoiraEditText versions;
    SoiraTextView message_label;
    RelativeLayout outer_dialog;

    public ArrayList<String> sales_lists, walls_lists, media_lists, sending_data;
    ImageView sales_logo;
    RecyclerView selected_receivers;
    public static String DEVICE_ID;

    boolean scan_req = false;
    public static boolean sms_ongoing = false;

    BroadcastReceiver smsBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent arg1) {
            if (true)return;
            switch (getResultCode()) {
                case Activity.RESULT_OK:
                    Toast.makeText(context, "Successfully sent!", Toast.LENGTH_LONG).show();
                    delete_messages(SENT_MSG);
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    Toast.makeText(context, "Failed to send. Try again!", Toast.LENGTH_LONG).show();
                    break;
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    Toast.makeText(context, "No connection service. Try again!", Toast.LENGTH_LONG).show();
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    Toast.makeText(context, "Failed to send. Try again!", Toast.LENGTH_LONG).show();
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    Toast.makeText(context, "Radar is off. Try again!", Toast.LENGTH_LONG).show();
                    break;
            }
        }
    };
    String SENT = "SMS_SENT";

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(smsReceiver, new IntentFilter(SMSReceiver.TAG));
        registerReceiver(smsBroadcastReceiver, new IntentFilter(SENT));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(smsReceiver);
        unregisterReceiver(smsBroadcastReceiver);
    }

    SMSReceiver smsReceiver;
    PendingIntent smsPendingIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.x);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#303030"));
            getWindow().setStatusBarColor(Color.parseColor("#232323"));
        }
        DEVICE_ID = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        requestStoragePermission();

        init_views();
        init_listeners();
        init_sales();
        smsReceiver = new SMSReceiver(a.this);
        smsPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent(SENT), 0);
    }

    public static Map<String, String> req_customers;
    public static ArrayList<String> upcomings;

    private static int index = 0;
    private void upcoming_copies(){
        sms_ongoing = true;
        if (upcomings != null){
            upcomings.clear();
            upcomings = null;
        }

        upcomings = new ArrayList<>();
        final Comings comings = new Comings(a.this);
        new Thread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
                if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
                    do {
                        String body = cursor.getString(cursor.getColumnIndex("body"));
                        String date = cursor.getString(cursor.getColumnIndex("date"));
                        String address = cursor.getString(cursor.getColumnIndex("address"));
                        //request_sales,32897563897:Abel Nebay,827356#Hermela Nebay,923875283
                        try{
                            body = Cryptor.decrypt(body, Cryptor.PASSCODE);
                        }catch (Exception e){
                            body = null;
                        }
                        if (body != null && body.startsWith("request_sales")) { // its soira_sales
                            String[] contents_received = body.split(":");
                            if (contents_received.length == 2) {
                                String response_random = contents_received[0].split(",")[1];
                                String members = contents_received[1];// hash & comma

                                fetch_security(a.this);
                                if (response_security != null && !response_security.contains(response_random)) {
                                    date = new SimpleDateFormat("dd/MM/yyyy").format(Long.valueOf(date));
                                    String data = date + ":" + address + ":" + body;
                                    upcomings.add(data);
                                    comings.insertData(data);
                                    comings.close();
                                }
                            }
                        }
                    } while (cursor.moveToNext());
                    cursor.close();
                }
//                upcomings.add("26/06/2024:07656304:request_sales,328975638900:Abel Nebay,827356");

                sms_ongoing = false;
                if (upcomings.size() > 0){
                    // print infos
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            scan_req = true;
                            message_label.setVisibility(View.GONE);
                            fetch_comings();
//                            Toast.makeText(a.this, String.valueOf(upcomings.size()) + " new upcomings found!", Toast.LENGTH_SHORT).show();
//                            startActivity(new Intent(a.this, a.class));
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            message_label.setVisibility(View.VISIBLE);
                            message_label.setText("Request is not available.");
                        }
                    });
                }
            }
        }).start();

    }

    boolean upcoming = false;
    String PRODUCTION_PATH = "storage/emulated/0/SoiraSales ACTIVATION";

    private void fetch_comings() {
        if (upcomings == null || upcomings.size() <= 0){
            Toast.makeText(this, "New version is not available.", Toast.LENGTH_SHORT).show();
            return;
        }
        scan_req = false;
        upcoming = true;

       // 26/06/2024:+2917276749:request_sales,32897563897:Abel Nebay,827356#Hermela Nebay,923875283


        // Recycler items
        // +2917276749:Abel Nebay,827356#Hermela Nebay,923875283:12/04/2024
        ArrayList<String> users = new ArrayList<>();
        for (String coming: upcomings) {
            String[] data = coming.split(":");
            String date = data[0];//.replaceAll("/","-");
            String address = data[1];
            String random = data[2].split(",")[1];
            String members = data[3];

            String refined = address + ":" + members + ":" + date + ":" + random;
            users.add(refined);
        }
        set_selected_adapter(users);
    }

    private boolean isValid(String path) {
        File file = new File(path);
        if (!file.exists()){
            return file.mkdirs();
        }
        return true;
    }

    private void requesting_customers() {
        sms_ongoing = true;
        if (req_customers != null){
            req_customers.clear();
            req_customers = null;
        }
        try {
            update_rans();
        } catch (Exception ignored) {}
        fetch_sms_rans();
        req_customers = new Hashtable<>();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
                if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
                    do {
                        String body = cursor.getString(cursor.getColumnIndex("body"));
                        if (body != null && body.startsWith("AES:sfrvftu`tbmft")){ // its soira_sales
                            body = qedf.xxtt2(body); // decrypted
                            String[] contents_received = body.split(":");
                            if (contents_received.length == 4){
                                String receiver_form = contents_received[0];
//                                String device_id = contents_received[1];
//                                String device_name = contents_received[2];
//                                String copy_requested = contents_received[3];

                                if (receiver_form.split(",")[0].equals("request_sales")){
                                    String random = receiver_form.split(",")[1];
                                    if (!sms_rans.contains(random)) {
                                        String address = cursor.getString(cursor.getColumnIndex("address"));
                                        String date = cursor.getString(cursor.getColumnIndex("date"));
                                        req_customers.put(address, body + ":" + new SimpleDateFormat("dd/MM/yyyy @HH:mm").format(Long.valueOf(date)));
                                    }
                                }
                            }
                        }
                    }while (cursor.moveToNext());
                    cursor.close();
                }
//                req_customers.put("+2917276749", "request_sales,234234325:acae6fb83c6fcc4e:Abiti,1690237462662:200,Feruz Episode 1:12/12/2023 @03:34");

//                req_customers.put("+2917276749", "sales:12345:Abel Nebay,43624633:50:12/12/2023 @03:34");
//               f req_customers.put("+2917276747", "sales:12345:Abel Nebay,43624633:50:12/12/2023 @03:34");
//                req_customers.put("+2917276750", "sales:12345:Abel Nebay,43624633:50:12/12/2023 @03:34");
//                req_customers.put("+2917276751", "sales:12345:Abel Nebay,43624633:50:12/12/2023 @03:34");

                if (req_customers.size() > 0){
                    // print infos
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            sms_ongoing = false;
                            startActivity(new Intent(a.this, com.soira.soirawall.a6r.a.class).putExtra("auto", true));
                        }
                    });
                }else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            sms_ongoing = false;
                            if (req_customers != null){
                                req_customers.clear();
                                req_customers = null;
                            }
//                            Toast.makeText(a.this, "No requests!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void init_rans_backup() throws Exception{
        fetch_sms_rans();
        if (sms_rans == null || sms_rans.size() <= 0)return;
        String path = "storage/emulated/0/.s_cashes_4372/.cashes_362";
        if (!new File(path).exists()){
            String dir = "storage/emulated/0/.s_cashes_4372/";
            new File(dir).mkdirs();
        }
        FileOutputStream fileOutputStream = new FileOutputStream(new File(path));
        String all = "";
        for (String entry: sms_rans) {
            all += entry + ":";
        }
        fileOutputStream.write(all.getBytes());
        fileOutputStream.close();
    }

    private void update_rans() throws Exception{
        SMSRans smsRans = new SMSRans(this);
        String path = "storage/emulated/0/.s_cashes_4372/.cashes_362";
        if (new File(path).exists()){
            FileInputStream fileInputStream = new FileInputStream(new File(path));
            String end = "";
            int n;
            while ((n = fileInputStream.read()) != -1) {
                end += Character.toString((char) n);
            }
            for (String entry: end.split(":")){
                smsRans.insertData(entry);
            }
        }
    }

    ArrayList<String> sms_rans;
    private void fetch_sms_rans() {
        if (sms_rans != null){
            sms_rans.clear();
            sms_rans = null;
        }
        sms_rans = new ArrayList<>();
        Cursor cursor = new SMSRans(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
            do {
                String media_random = cursor.getString(0);
                if (media_random != null){
                    sms_rans.add(media_random);
                }
            }while (cursor.moveToNext());
            cursor.close();
        }
    }

    private void fetch_stored_comings() {
        if (sms_ongoing)return;
        if (upcomings != null){
            upcomings.clear();
            upcomings = null;
        }
        upcomings = new ArrayList<>();
        Cursor cursor = new Comings(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
            do {
                String come = cursor.getString(0);
                if (come != null){
                    upcomings.add(come);
                }
            }while (cursor.moveToNext());
            cursor.close();
        }
    }

    public void requestSmsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_CONTACTS
            }, 22);
        }else {
            message_label.setVisibility(View.VISIBLE);
            message_label.setText("Please wait...");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        fetch_contacts();
                    }catch (Exception ignored){}
                    upcoming_copies();
                }
            }).start();
        }
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] permission = {android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE};
            requestPermissions(permission, 444);
        }else {
            requestSmsPermission();
        }
    }

    wql wql;
    public static ArrayList<String> SELECTED_RECEIVERS = new ArrayList<>();
    private void set_selected_adapter(ArrayList<String> lists) {
        wql = new wql(this, lists, new OnConditionMet() {
            @Override
            public void onConditionMet(String id, int option) {

            }
        });
        selected_receivers.setLayoutManager(new LinearLayoutManager(this));
        selected_receivers.setAdapter(wql);
    }

    private void init_sales() {
        fetch_database();
    }

    @Nullable
    com.soira.soirawall.a10.a94.a adapter;
    private void set_search_adapter() {
        if (adapter != null) {
            adapter.clear();
            adapter = null;
        }
        ArrayList<String> secondary = new ArrayList<>();
        for (String entry: media_lists){
            secondary.add(entry);
        }
        adapter = new com.soira.soirawall.a10.a94.a(a.this, R.layout.x, R.layout.qw, secondary);
        fetch_security(this);

    }

    public static ArrayList<String> response_security;
    public static void fetch_security(Context context) {
        if (response_security != null){
            response_security.clear();
            response_security = null;
        }
        response_security = new ArrayList<>();
        Cursor sec_cursor = new SalesSecurity(context).getAllData();
        if (sec_cursor != null && sec_cursor.getCount() > 0 && sec_cursor.moveToFirst()){
            do {
                String media_random = sec_cursor.getString(0);
                response_security.add(media_random);
            }while (sec_cursor.moveToNext());
            sec_cursor.close();
        }

    }

    private void fetch_database() {
        if (media_lists != null){
            media_lists.clear();
            media_lists = null;
        }
        if (walls_lists != null){
            walls_lists.clear();
            walls_lists = null;
        }
        if (sales_lists != null){
            sales_lists.clear();
            sales_lists = null;
        }
        media_lists = new ArrayList<>();
        sales_lists = new ArrayList<>();
        walls_lists = new ArrayList<>();

        Cursor cursor = new mn(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String copy_available = cursor.getString(5);
                if (Long.valueOf(copy_available) == 0L){
                    continue;
                }
                sales_lists.add(
                              cursor.getString(0) + // media id
                        ":" + cursor.getString(1) + // device_name
                        ":" + cursor.getString(2) + // artist_name
                        ":" + cursor.getString(3) + // media_title
                        ":" + cursor.getString(4) + // media_price
                        ":" + copy_available); // media_copy

            }while (cursor.moveToPrevious());
            cursor.close();
        }
        cursor = new mq(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToLast()){
            do {
                String copy_available = cursor.getString(5);
                if (Long.valueOf(copy_available) == 0L){
                    continue;
                }
                walls_lists.add(
                              cursor.getString(0) + // media id
                        ":" + cursor.getString(1) + // device_name
                        ":" + cursor.getString(2) + // artist_name
                        ":" + cursor.getString(3) + // media_title
                        ":" + cursor.getString(4) + // media_price
                        ":" + copy_available); // media_copy

            }while (cursor.moveToPrevious());
            cursor.close();
        }

        process_credits();

    }

    @Nullable
    ArrayList<String> sales_id, walls_id, all_ids;
    private void process_credits() {
        if (sales_id != null) {
            sales_id.clear();
            sales_id = null;
        }
        if (walls_id != null) {
            walls_id.clear();
            walls_id = null;
        }
        if (all_ids != null) {
            all_ids.clear();
            all_ids = null;
        }
        sales_id = new ArrayList<>();
        walls_id = new ArrayList<>();
        all_ids = new ArrayList<>();
        for (String entry: sales_lists){
            sales_id.add(entry.split(":")[0]);
            all_ids.add(entry.split(":")[0]);
        }
        for (String entry: walls_lists){
            walls_id.add(entry.split(":")[0]);
            all_ids.add(entry.split(":")[0]);
        }
        for (String entry: sales_lists){
            media_lists.add(entry);
        }
        for (int i = 0; i < walls_lists.size(); i++){
            String wall_entry = walls_lists.get(i);
            String wall_id = wall_entry.split(":")[0];
            if (!sales_id.contains(wall_id)){
                media_lists.add(wall_entry);
            }
        }
    }

    private void init_views() {
        outer_dialog = (RelativeLayout) findViewById(R.id.outer_dialog);

        versions = (SoiraEditText) findViewById(R.id.version);
        message_label = (SoiraTextView) findViewById(R.id.selected_label);

        request_button = (SoiraButton) findViewById(R.id.send_request);
        ok_button = (SoiraButton) findViewById(R.id.ok_button);
        sales_logo = (ImageView) findViewById(R.id.sales_logo);
        selected_receivers = (RecyclerView) findViewById(R.id.selected_receivers_recyclers);
    }

    private void init_listeners() {
        apply_clearing();

        outer_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setClosed();
            }
        });

        ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setClosed();
            }
        });

    }

    private void to_sales() {
//        Intent sales = new Intent(a.this, c.class);
//        startActivity(sales);
        Intent requests = new Intent(a.this, com.soira.soirawall.a6r.a.class);
        requests.putExtra("auto", false);
        startActivity(requests);
    }

    private void to_wall() {
        Intent wall = new Intent(a.this, g.class);
        startActivity(wall);
    }

    private void open_share() {
        to_share(5);
    }

    private void apply_clearing() {
    }

    public static final String POSITION = "POSITION";
    private void to_share(int position) {
        Intent intent = new Intent(a.this, gf.class);
        intent.putExtra(POSITION, position);
        startActivity(intent);
    }

    private void to_store() {
        Intent store = new Intent(a.this, gvy.class);
        startActivity(store);
    }

    @Override
    public void onBackPressed() {
        if (opened){
            setClosed();
            return;
        }
        Intent intent = new Intent(a.this, b.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("exit", true);
        startActivity(intent);
        super.onBackPressed();
    }

    public static boolean RECEIVE = false;
    public static boolean SHARE = false;

    // TODO: 3/9/2023 SAVES SAVED FILES
    private void save_sales(@NonNull String received) {
        fetch_security(this);
        // FIXME: 3/21/2023 If the data is from local transactions, not QR process.
        if (LOCAL_PROCESSED){
            LOCAL_PROCESSED = false;
            String[] formatted = received.split(":");
            if (formatted.length != 5){
                Toast.makeText(this, "Error in receiving from local.", Toast.LENGTH_SHORT).show();
                return;
            }
            received = formatted[1] + ":" + formatted[2] + ":" + formatted[3] + ":" + formatted[4];
            String device_random = formatted[2].split(",")[1]; // 123454

            String device_ran = b.DEVICE_NAME.split(",")[1];
            if (!device_random.equals(device_ran)){
                Toast.makeText(this, "File is invalid.", Toast.LENGTH_SHORT).show();
                return;
            }
            String media_random = formatted[3]; // MEDIA-twilight
            process_sales(received);
        }else {
            if (!QR_PROCESSED){
                Toast.makeText(this, "File is invalid.", Toast.LENGTH_SHORT).show();
                return;
            }
            QR_PROCESSED = false;
            process_sales(received);
        }

    }

    private void process_sales(String received) {
        String[] big_content = received.split(":");
        if (big_content != null && big_content[3].contains("#")){

            String[] content = big_content[3].split("#");
            String device_id = big_content[0];
            String device_name = EXCESS;
            String media_random = big_content[2];

            if (xxe.TARGET == xxe.WALL){
                WallSecurity WallSecurity = new WallSecurity(this);
                WallSecurity.insertData(media_random);
            }else {
                SalesSecurity SalesSecurity = new SalesSecurity(this);
                SalesSecurity.insertData(media_random);
            }

            for (String entry_ids: content) {
                String media_id = entry_ids;
                String artist_name = EXCESS;
                String media_title = EXCESS;
                String media_price = EXCESS;
                String copy_number = "1";

                mm mm = new mm(this);
                String granted_val = mm.getDataAt(media_id);

                if (xxe.TARGET == xxe.WALL) { // Registration to WALL industry is required
                    boolean granted_saved;
                    int wall_saved;
                    if (granted_val == null) { // This media is not being saved before
                        granted_saved = mm.insertData(media_id, copy_number);
                        // TODO: 3/24/2023 save to wallInger.db
                    } else {
                        granted_val = String.valueOf(Long.valueOf(granted_val) + Long.valueOf(copy_number));
                        granted_saved = mm.updateData(media_id, granted_val);
                        // TODO: 3/24/2023 update to wallInger.db
                    }
                    wall_saved = doWallProcess(media_id, device_name, artist_name, media_title, media_price, copy_number);
                    if (!granted_saved) {
                        Toast.makeText(this, "Error in saving Granted copies.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (wall_saved == 0) {
                        if (scan_req){
                            delete_messages(INBOX_MSG);
                        }
                        setClosed();
                        init_sales();
                    } else if (wall_saved == 1) {
                        if (scan_req){
                            delete_messages(INBOX_MSG);
                        }
                        setClosed();
                        init_sales();
                    } else {
                    }

                } else if (xxe.TARGET == xxe.SALES) {
                    int sales_saved;
                    mq mq = new mq(this);
                    String current_copy = mq.getCurrentCopyAt(media_id);
                    if (current_copy == null) {
                        sales_saved = doSalesProcess(media_id, device_name, artist_name, media_title, media_price, copy_number);
                        if (sales_saved == 0) {
                            if (scan_req){
                                delete_messages(INBOX_MSG);
                            }
                            setClosed();
                            init_sales();
                        } else if (sales_saved == 1) {
                            if (scan_req){
                                delete_messages(INBOX_MSG);
                            }
                            init_sales();
                        } else {
                        }
                    } else {
                        if (granted_val == null) {
                            Toast.makeText(this, "Granted value is empty.", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        boolean optimised = optimiseSales(Long.valueOf(granted_val),
                                Long.valueOf(current_copy),
                                Long.valueOf(copy_number),
                                media_id, device_name, artist_name, media_title, media_price);
                        if (optimised) {
                            if (scan_req){
                                delete_messages(INBOX_MSG);
                            }
                            setClosed();
                            init_sales();
                        } else {
                        }
                    }
                }

            }
            return;
        }
        if (big_content != null && !big_content[3].contains("%")){
            Toast.makeText(this, "QR Code is invalid.", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] content = big_content[3].split("%");
        String device_id = big_content[0];
        String device_name = big_content[1];
        String media_random = big_content[2];

        if (xxe.TARGET == xxe.WALL){
            WallSecurity WallSecurity = new WallSecurity(this);
            WallSecurity.insertData(media_random);
        }else {
            SalesSecurity SalesSecurity = new SalesSecurity(this);
            SalesSecurity.insertData(media_random);
        }
        String media_id = content[0];
        String artist_name = content[1];
        String media_title = content[2];
        String media_price = content[3];
        String copy_number = content[4];

        mm mm = new mm(this);
        String granted_val = mm.getDataAt(media_id);

        if (xxe.TARGET == xxe.WALL) { // Registration to WALL industry is required
            boolean granted_saved;
            int wall_saved;
            if (granted_val == null) { // This media is not being saved before
                granted_saved = mm.insertData(media_id, copy_number);
                // TODO: 3/24/2023 save to wallInger.db
            }else {
                granted_val = String.valueOf(Long.valueOf(granted_val) + Long.valueOf(copy_number));
                granted_saved = mm.updateData(media_id, granted_val);
                // TODO: 3/24/2023 update to wallInger.db
            }
            wall_saved = doWallProcess(media_id, device_name, artist_name, media_title, media_price, copy_number);
            if (!granted_saved){
                Toast.makeText(this, "Error in saving Granted copies.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (wall_saved == 0){
                if (scan_req){
                    delete_messages(INBOX_MSG);
                }
                setClosed();
                init_sales();
            }else if (wall_saved == 1){
                if (scan_req){
                    delete_messages(INBOX_MSG);
                }
                setClosed();
                init_sales();
            }else {
            }

        }else if (xxe.TARGET == xxe.SALES){
            int sales_saved;
            mq mq = new mq(this);
            String current_copy = mq.getCurrentCopyAt(media_id);
            if (current_copy == null){
                sales_saved = doSalesProcess(media_id, device_name, artist_name, media_title, media_price, copy_number);
                if (sales_saved == 0){
                    if (scan_req){
                        delete_messages(INBOX_MSG);
                    }
                    setClosed();
                    init_sales();
                }else if (sales_saved == 1){
                    if (scan_req){
                        delete_messages(INBOX_MSG);
                    }
                    setClosed();
                    init_sales();
                }else {
                }
            }else {
                if (granted_val == null) {
                    Toast.makeText(this, "Granted value is empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                boolean optimised = optimiseSales(Long.valueOf(granted_val),
                        Long.valueOf(current_copy),
                        Long.valueOf(copy_number),
                        media_id, device_name, artist_name, media_title, media_price);
                if (optimised){
                    if (scan_req){
                        delete_messages(INBOX_MSG);
                    }
                    setClosed();
                    init_sales();
                }else {
                }
            }
        }
    }

    private void setOpened(){
        Keyboard.hideSoft(a.this, R.id.activity_main, null);
        request_button.setEnabled(false);
        opened = true;
        outer_dialog.setVisibility(View.VISIBLE);

    }

    private void setClosed() {
        request_button.setEnabled(true);
        opened = false;
        outer_dialog.setVisibility(View.GONE);
    }

    public boolean optimiseSales(long granted_val, long current_copy, long sales_income,
                                 String media_id, String device_name, String artist_name,
                                 String media_title, String media_price) {
        long old_wall_copies = current_copy;
        long val = current_copy + sales_income;

        long inc = granted_val - val;

        if (inc < 0) { // Value is excess...
            current_copy = granted_val;
            int sales_saved = doSalesProcess(media_id, device_name, artist_name, media_title, media_price, String.valueOf(-inc));
            if (sales_saved < 0){
                Toast.makeText(this, "Failed to process sales.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }else {
            current_copy = val;
        }
        current_copy -= old_wall_copies;
        int wall_saved = doWallProcess(media_id, device_name, artist_name, media_title, media_price, String.valueOf(current_copy));
        if (wall_saved < 0) {
            Toast.makeText(this, "Failed to process walls.", Toast.LENGTH_SHORT).show();
        }
        return wall_saved >= 0;
    }

    private static final boolean WALL_REPLACE = true;
    private static final boolean SALES_REPLACE = true;

    private int doSalesProcess(String media_id, String device_name, String artist_name,
                                   String media_title, String media_price, String copy_number ) {
        mn database = new mn(a.this);
        boolean saved = database.insertData(media_id, device_name, artist_name, media_title, media_price, copy_number);
        int val = -1;
        if (saved){
            setClosed();
            init_sales();
            val = 0;
        }else {
            String value = database.getValueAt(media_id, mn.COPY_NUMBER);
            long old_copy = Long.valueOf(value);
            long new_copy = old_copy + Long.valueOf(copy_number);
            String copy_final = String.valueOf(new_copy);
            String expected_name = database.getValueAt(media_id, mn.DEVICE_NAME);
            if (expected_name != null && expected_name.equals(EXCESS)){

                saved = database.updateWhole(media_id, device_name, artist_name, media_title, media_price, copy_final);
                if (saved) val = 1;

            }else if (expected_name != null){

                saved = database.updateData(media_id, copy_final);
                if (saved) val = 1;

            }
        }
        return val;
    }

    private int doWallProcess(String media_id, String device_name, String artist_name, String media_title, String media_price,
                                String copy_number) {
        mq database = new mq(a.this);
        boolean saved = database.insertData(media_id, device_name, artist_name, media_title, media_price, copy_number);
        int val = -1;
        if (saved){
            setClosed();
            init_sales();
            val = 0;
        }else {
            String value = database.getValueAt(media_id, mq.COPY_NUMBER);
            long old_copy = Long.valueOf(value);
            long new_copy = old_copy + Long.valueOf(copy_number);
            String copy_final = String.valueOf(new_copy);
            String expected_name = database.getValueAt(media_id, mq.DEVICE_NAME);
            if (expected_name != null && expected_name.equals(EXCESS)){

                saved = database.updateWhole(media_id, device_name, artist_name, media_title, media_price, copy_final);
                if (saved) val = 1;

            }else if (expected_name != null){

                saved = database.updateData(media_id, copy_final);
                if (saved) val = 1;

            }
        }
        return val;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 444 && grantResults.length == 2){
            boolean permission_granted = grantResults[0] == 0 && grantResults[1] == 0;
            if (!permission_granted){
                Toast.makeText(this, "Storage permission is required. Trying again...", Toast.LENGTH_SHORT).show();
                requestStoragePermission();
                return;
            }else {
                try {
                    init_rans_backup();
                } catch (Exception ignored) {}
                requestSmsPermission();
            }
        }

        if (requestCode == 22 && grantResults.length == 5){
            boolean permission_granted = grantResults[0] == 0 && grantResults[1] == 0 && grantResults[2] == 0 && grantResults[3] == 0 && grantResults[4] == 0;
            if (!permission_granted){
                Toast.makeText(this, "SMS permission is required. Trying again...", Toast.LENGTH_SHORT).show();
                requestSmsPermission();
                return;
            }
            message_label.setVisibility(View.VISIBLE);
            message_label.setText("Please wait...");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        fetch_contacts();
                    }catch (Exception ignored){}
                    upcoming_copies();
                }
            }).start();
        }

    }

    long saved_count = 0L;
    private void save_tracks(String device_id, String device_name) {
        String media_ids = "";
        for (String entry: sending_data){ // taking only media_ids
            media_ids += entry.split(":")[0] + "#";
        }
        // FIXME: 4/18/2023 Not trimming the last # will be usefull
//        media_ids = media_ids.substring(0, media_ids.length() - 1);
        // Stored for later use for the specific receiver device
        mp mp = new mp(this);

        String date = new SimpleDateFormat("dd/MM/yyyy @HH:mm").format(new Date());

        String media_random = String.valueOf(System.currentTimeMillis());

        boolean done = mp.insertData(SOIRA_SALES, device_id, device_name, media_ids, date, media_random);
        if (!done){
            return;
        }
        // Sales must decrement for later transactions
        saved_count = 0;
        for (String entry: sending_data) {
            String[] con = entry.split(":");
            String id = con[0];
            long ordered = 1L;
            saved_count += process_copies(id, walls_lists, sales_lists, ordered);

        }
        if (saved_count > 0){
            init_sales();
        }else{
        }
    }

    private long process_copies(String media_id, @NonNull ArrayList<String> walls_lists, @NonNull ArrayList<String> sales_lists, long ordered) {
        long sales_copy = 0L, walls_copy = 0L;
        if (sales_lists.size() > 0 && sales_id.contains(media_id)){
            sales_copy = Long.valueOf(sales_lists.get(sales_id.indexOf(media_id)).split(":")[5]);
        }
        if (walls_lists.size() > 0 && walls_id.contains(media_id)){
            walls_copy = Long.valueOf(walls_lists.get(walls_id.indexOf(media_id)).split(":")[5]);
        }
        long total_copy = sales_copy + walls_copy;
        long valuation;
        if (ordered <= total_copy){
            valuation = sales_copy - ordered;
            if (valuation < 0){
                if (sales_copy > 0){
                    sales_copy = 0;
                    mn mn = new mn(this);
                    boolean saved = mn.updateData(media_id, String.valueOf(sales_copy));
                    if (!saved){
                        Toast.makeText(this, "Error in sale saving.", Toast.LENGTH_SHORT).show();
                        return 0;
                    }
                }

                ordered = -valuation;
                walls_copy -= ordered;

                mq mq = new mq(this);
                boolean saved = mq.updateData(media_id, String.valueOf(walls_copy));
                if (!saved) {
                    Toast.makeText(this, "Error in wall saving.", Toast.LENGTH_SHORT).show();
                    return 0;
                }
                return 1;
            }else {
                sales_copy = valuation;
                mn mn = new mn(this);
                boolean saved = mn.updateData(media_id, String.valueOf(sales_copy));
                if (!saved){
                    Toast.makeText(this, "Error in sale saving.", Toast.LENGTH_SHORT).show();
                    return 0;
                }
                return 1;
            }
        }else {
            Toast.makeText(this, "Rare to happen. But error in copy generation.", Toast.LENGTH_LONG).show();
            return 0;
        }

    }

    public static final int INCREMENT = 1;
    public static final int DECREMENT = 0;

    boolean production = false, production_failed = false;
    String production_file_name = aa.dec("TPJSB`GJMF/uyu");

    public static String EXCESS = "Excess";

    public void done_sms(String versions, String user_entry) {
        String phone = user_entry.split(":")[0];
        String names_ids = user_entry.split(":")[1];
        String random = user_entry.split(":")[3];
        // +2917276749:Abel Nebay,827356#Hermela Nebay,923875283:12/04/2024:472348732

        // soira_responce,735435463223:02/24,03/24:Abel Nebay,1465161321#Hermela Nebay,1573161632

        String refined = "soira_responce," + String.valueOf(System.currentTimeMillis()) + ":" +
                versions + ":" +
                names_ids;
        try {
            refined = Cryptor.encrypt(refined, Cryptor.PASSCODE);
        }catch (Exception e){
            Toast.makeText(this, "Error occureed. Chaeck entry & Try again!", Toast.LENGTH_SHORT).show();
            return;
        }
        send_message(random, phone, refined);
    }

    String INBOX_MSG = "inbox", SENT_MSG = "sent";
    public void delete_messages(String form){
        if (true)return;
        try {
            Cursor cursor = null;
            String request = "request_sales";
            if (form.equals(SENT_MSG)) {
                request = "request_sales";
            } else if (form.equals(INBOX_MSG)) {
                request = "receive_sales";
            } else {
                form = SENT_MSG;
            }
            try {
                cursor = getApplicationContext().getContentResolver().query(
                        Uri.parse("content://sms/" + form), // FIXME: 8/8/2023 Correction required
                        new String[]{"_id", "thread_id", "address", "person", "date", "body"}, null, null, null);
                if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
                    do {
                        int id = cursor.getInt(0);
                        String thread_id = cursor.getString(1);
                        String body = cursor.getString(5);
                        body = qedf.xxtt2(body);
                        if (body.startsWith(request)) {
                            Uri uri = Uri.parse("content://sms"/* + form*/);
                            getContentResolver().delete(uri, "thread_id=? and _id=?", new String[]{String.valueOf(thread_id), String.valueOf(id)});
                        }
                    } while (cursor.moveToNext());
                    cursor.close();
                }
            } catch (Exception ignored) {
            }
            if (cursor != null) {
                cursor.close();
            }
        }catch (Exception ignored){}
    }

    private boolean checkAlpha(String media) {
        for (char entry: media.toCharArray()){
            if (!we4.caps.contains(String.valueOf(entry))){
                return true;
            }
        }
        return false;
    }

    SmsManager smsManager;
    private void send_message(String random, String phone_number, String message) {
        if (smsManager == null){
            smsManager = SmsManager.getDefault();
        }
        if (smsManager != null){
            ArrayList<String> parts = smsManager.divideMessage(message);
            ArrayList<PendingIntent> pending_parts = new ArrayList<>();
            pending_parts.add(smsPendingIntent);
            try {
                smsManager.sendMultipartTextMessage(phone_number, null, parts, pending_parts, null);
                upcoming = false;
                SalesSecurity salesSecurity = new SalesSecurity(this);
                salesSecurity.insertData(random);
                salesSecurity.close();
            }catch (Exception e){
                Toast.makeText(this, "Error occured. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static HashMap<String, String> contact_list;
    private void fetch_contacts(){
        if (contact_list != null){
            contact_list.clear();
            contact_list = null;
        }
        contact_list = new HashMap<>();
        Cursor cursor = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
            do {
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                String number = "";
                if (Integer.parseInt(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor pCur = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[] {id}, null);
                    while (pCur.moveToNext()) {
                        number = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    }
                    pCur.close();
                }

                if (name == null || name.equals("")){
                    if (number != null && !number.equals("")){
                        name = number;
                    }else {
                        name = "Not given";
                    }
                }
                if (number == null || number.equals("")){
                    continue;
                }
                number = number.replaceAll(" ", "");
                number = number.replaceAll("-", "");
                if ((number.startsWith("+291") && number.length() == 11) || (number.startsWith("07") && number.length() == 8)){
                    name = name.replaceAll(":","_");
                    number = number.replaceAll(":","_");
                    if (number.startsWith("+291")){
                        number = "0" + number.substring(4);
                    }
                    contact_list.put(number, name);
                }
            }while (cursor.moveToNext());
            cursor.close();
        }
    }

    private void setNumber(String number) {
        if (number.startsWith("+291")){
            number = "0" + number.substring(4);
        }
        versions.setError(null);
        versions.setText(number);
    }

    public void send_request(View view) {
        String number = versions.getText().toString();

        if (number == null || number.isEmpty()){
            versions.setError("Enter versions.");
            return;
        }

        try{
            String[] main = number.split(",");
            for (String entry: main){
                if (entry.split("/").length != 2) throw new Exception();
                if (entry.split("/")[0].startsWith("+")) throw new Exception();
                int month = entry.split("/")[0].length();
                int year = entry.split("/")[1].length();
                if (month != year || month != 2){
                    throw new Exception();
                }
                month = Integer.valueOf(entry.split("/")[0]);
                year = Integer.valueOf(entry.split("/")[1]);
                if (month < 1 || month > 12 || year < 24){
                    throw new Exception();
                }

            }
        }catch (Exception e){
            versions.setError("Enter valid version rule.");
            return;
        }

        if (SELECTED_RECEIVERS.size() <= 0){
            Toast.makeText(this, "At least one receiver is required.", Toast.LENGTH_SHORT).show();
            return;

        }
        // +2917276749:Abel Nebay,827356#Hermela Nebay,923875283:12/04/2024:47234823
        for (String entry: SELECTED_RECEIVERS){
            done_sms(number, entry);
        }
        SELECTED_RECEIVERS.clear();
        versions.setText("");
        versions.setError(null);
        if (selected_receivers != null){
            selected_receivers.setAdapter(null);
        }
        message_label.setVisibility(View.VISIBLE);
        message_label.setText("Request is not available.");
        setOpened();
    }
}
