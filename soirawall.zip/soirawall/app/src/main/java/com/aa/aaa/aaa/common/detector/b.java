package com.aa.aaa.aaa.common.detector;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.we4;
import com.soira.soirawall.R;
import com.aa.aaa.aaa.datamatrix.encoder.a;
import com.soira.soirawall.aqp.Keyboard;
import com.soira.soirawall.sq3.SoiraAutoCompleteTextView;
import com.soira.soirawall.sq3.SoiraButton;

@SuppressWarnings("ALL")
public class b extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    RelativeLayout outer_alert, inner_alert;
    SoiraButton cancel_button, done_button;
    SoiraAutoCompleteTextView user_entry;
    ImageView splash_image, clear_text;

    private final static String USER_SET = "USER_SET";
    public final static String DEVICE_SET = "DEVICE_SET";
    public final static String INTRO = "INTRO";

    public final static String SOIRA_PLAYER = "soira_player";
    public final static String SOIRA_SALES = "soira_sales";
    public final static String SOIRA_WALL = "soira_wall";

    @Nullable
    public static String DEVICE_NAME;
    public static boolean QR_PROCESSED = false, LOCAL_PROCESSED = false;

    private boolean checkAlpha(String media) {
        for (char entry: media.toCharArray()){
            if (!we4.caps.contains(String.valueOf(entry))){
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean then = getIntent().getBooleanExtra("exit", false);
        if (then){
            finish();
        }
    }

    public static boolean EXPIRED = false;
    public static boolean INVALID = false;
    public static String device_random = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.de);

        init_views();
        init_listeners();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#303030"));
        }
        head_next();
    }

    public void accept(View view) {
        editor.putBoolean(LICENSE, true).apply();
        close_license();
        check_protocol();
    }

    private void open_license() {
        license_open = true;
        fading.setVisibility(View.VISIBLE);
        license.setVisibility(View.VISIBLE);
    }

    private void close_license() {
        license_open = false;
        license.setVisibility(View.GONE);
        fading.setVisibility(View.GONE);
    }

    private void check_protocol(){
        if (!sharedPreferences.getBoolean(USER_SET, false)){
            device_random = String.valueOf(System.currentTimeMillis());
            setOpened(getDeviceModel());
        }else {
            DEVICE_NAME = sharedPreferences.getString(DEVICE_SET, null);
            head_next();
        }
    }

    private void head_next(){
        splash_image.setVisibility(View.VISIBLE);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(b.this, a.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        }, 1000); // For quick access, use 0L! - Is there problem? - Absolutely, No!

    }

    private void init_listeners() {
        fading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // nothing
            }
        });

        license.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // nothing
            }
        });

        outer_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing
            }
        });

        inner_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing for something...
            }
        });

        clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_entry.setText("");
                clear_text.setVisibility(View.GONE);
            }
        });

        done_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String entered = user_entry.getText().toString();

                if (entered != null && entered.length() > 0) {
                    if (entered.contains(",")){
                        user_entry.setError("\",\" (Coma) letter is not allowed.");
                        return;
                    }

                    if (entered.contains(":")){
                        user_entry.setError("\":\" (Colon) letter is not allowed.");
                        return;
                    }

                    boolean error = checkAlpha(entered);
                    if (error){
                        user_entry.setError("Only English alphabets are allowed.");
                        return;
                    }

                    DEVICE_NAME = entered + "," + device_random;
                    editor.putString(DEVICE_SET, DEVICE_NAME).apply();
                    editor.putBoolean(USER_SET, true).apply();
                    setClosed();
                    head_next();
                    return;
                }
                user_entry.setError("Please enter username.");
            }
        });

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

//                DEVICE_NAME = getDeviceModel() + "," + device_random;
//                editor.putString(DEVICE_SET, DEVICE_NAME).apply();
//                editor.putBoolean(USER_SET, true).apply();
//                setClosed();
//                head_next();
            }
        });

        user_entry.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                apply_clearing();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public static String getDeviceModel(){
        if (device_random == null){
            device_random = String.valueOf(System.currentTimeMillis());
        }
        if (Build.MODEL != null && !Build.MODEL.equals("")){
            String formatted = Build.MODEL.replaceAll(",", "_");
            return formatted + "," + device_random;
        }else {
            return "Soira User," + device_random;
        }
    }
    
    private void apply_clearing() {
        if (user_entry.getText().length() > 0){
            clear_text.setVisibility(View.VISIBLE);
        }else {
            clear_text.setVisibility(View.GONE);
        }
    }

    private static final String LICENSE = "LICENSE";

    RelativeLayout license, fading;
    private void init_views() {
        fading = (RelativeLayout) findViewById(R.id.fading);
        license = (RelativeLayout) findViewById(R.id.license);
        sharedPreferences = getSharedPreferences(INTRO, MODE_PRIVATE);
        editor = sharedPreferences.edit();

        outer_alert = (RelativeLayout) findViewById(R.id.outer_alert);
        inner_alert = (RelativeLayout) findViewById(R.id.inner_alert);
        done_button = (SoiraButton) findViewById(R.id.done_button);
        cancel_button = (SoiraButton) findViewById(R.id.cancel_button);

        user_entry = (SoiraAutoCompleteTextView) findViewById(R.id.search_query);

        splash_image = (ImageView) findViewById(R.id.splash_image);
        clear_text = (ImageView) findViewById(R.id.user_clear_text);
    }
    boolean license_open = false;
    @Override
    public void onBackPressed() {
        if (opened || license_open){
            finish();
        }
    }
    boolean opened = false;
    private void setClosed(){
        Keyboard.hideSoft(this, R.id.splash_layout, user_entry);
        inner_alert.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                outer_alert.setVisibility(View.GONE);
                opened = false;
            }
        });
    }

    private void setOpened(String default_name){

        inner_alert.setScaleX(0);
        inner_alert.setScaleY(0);
        outer_alert.setVisibility(View.VISIBLE);

        inner_alert.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                if (user_entry.isFocusable()){
                    user_entry.requestFocus();
                }
                Keyboard.openSoft(b.this, user_entry);
            }
        });
    }

}
