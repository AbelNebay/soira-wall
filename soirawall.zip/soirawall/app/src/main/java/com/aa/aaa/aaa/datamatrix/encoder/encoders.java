package com.aa.aaa.aaa.datamatrix.encoder;


import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.RelativeLayout;


import com.aaa.client.result.runnable.extra.bitconde.pax.far.conb.decoder.we4;
import com.soira.soirawall.R;
import com.soira.soirawall.sq3.SoiraTextView;

import static com.aa.aaa.aaa.common.detector.b.DEVICE_NAME;
import static com.aa.aaa.aaa.common.detector.b.DEVICE_SET;
import static com.aa.aaa.aaa.common.detector.b.INTRO;

public class encoders extends AppCompatActivity {

    RelativeLayout outer_dialog, inner_dialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vgt);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#303030"));
            getWindow().setStatusBarColor(Color.parseColor("#303030"));

        }
        current_name = (SoiraTextView) findViewById(R.id.current_name);
        outer_dialog = (RelativeLayout) findViewById(R.id.outer_dialog);
        inner_dialog = (RelativeLayout) findViewById(R.id.inner_dialog);
    }

    SoiraTextView current_name;
    private void setDefaultName() {
        SharedPreferences sharedPreferences = getSharedPreferences(INTRO, MODE_PRIVATE);
        String device_name = sharedPreferences.getString(DEVICE_SET, null);
        if (device_name != null && device_name.contains(",") && device_name.split(",").length == 2){
            device_name = device_name.split(",")[0];
            current_name.setText(device_name);
        }

    }

    public void back(View view) {
        onBackPressed();
    }

    private boolean checkAlpha(String media) {
        for (char entry: media.toCharArray()){
            if (!we4.caps.contains(String.valueOf(entry))){
                return true;
            }
        }
        return false;
    }

    private void change_name(String new_name) {
        SharedPreferences sharedPreferences = getSharedPreferences(INTRO, MODE_PRIVATE);
        String device_random = sharedPreferences.getString(DEVICE_SET, null);
        if (device_random != null && device_random.contains(",") && device_random.split(",").length == 2){
            device_random = device_random.split(",")[1];
            sharedPreferences.edit().putString(DEVICE_SET, new_name + "," + device_random).apply();
            setSuccessDialog("");
            current_name.setText(new_name);
            DEVICE_NAME = new_name + "," + device_random;
        }
    }

    private void close_dialog(){
        inner_dialog.animate().scaleX(0).scaleY(0).setDuration(120).setInterpolator(new AnticipateInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                outer_dialog.setVisibility(View.GONE);
                dialog_opened = false;
            }
        });
    }

    boolean dialog_opened = false;
    private void open_dialog(){
        inner_dialog.setScaleX(0);
        inner_dialog.setScaleY(0);
        outer_dialog.setVisibility(View.VISIBLE);

        inner_dialog.animate().scaleX(1).scaleY(1).setDuration(120).setInterpolator(new OvershootInterpolator()).withEndAction(new Runnable() {
            @Override
            public void run() {
                dialog_opened = true;
            }
        });
    }

    private void setSuccessDialog(String message) {
        open_dialog();
    }


    @Override
    public void onBackPressed() {
        if (dialog_opened){
            close_dialog();
            return;
        }
        super.onBackPressed();
    }

    public void ok_change(View view) {
        close_dialog();
    }
}
